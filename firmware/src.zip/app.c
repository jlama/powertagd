/***************************************************************************//**
 * @file app.c
 * @brief Callbacks implementation and application specific code.
 *******************************************************************************
 * # License
 * <b>Copyright 2021 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#include PLATFORM_HEADER

#include "sl_component_catalog.h"
#include "hal.h"
#include "stack/include/ember.h"
#include "stack/include/gp-types.h"
#include "stack/include/ccm-star.h"
#include "app/util/ezsp/ezsp-enum.h"
#include "zigbee_app_framework_common.h"

#include "multirail.h"

// The time between receiving a GP packet and sending a scheduled response
#define GP_RX_OFFSET_USEC 25500

#define GP_CMD_CHANNEL_REQ    0xe3
#define GP_CMD_CHANNEL_CONFIG 0xf3

#define EMBER_GP_SECURITY_MIC_LENGTH 4
#define SECURITY_BLOCK_SIZE          16
#define MAX_PAYLOAD_LEN 70

// NWK FC = [Ext NWK Header = 0b1 || Auto-Commissioning =0b0|| ZigBee Protocol 0b0011 || Frame type =0b00] = 0x8c
#define HEADER_FLAG_NWK_FC 0x8C

// NWK FC Extended = [Direction = 0b0 || RxAfterTx = 0b0 || SecurityKey = 0b0 ||SecurityLevel(2 bits) || ApplID(3 bits)]
#define MAKE_HEADER_FLAG_NWK_FC_EXT(direction, rxAfterTx, keyType, securityLevel, appId) \
	((direction << 7) + (rxAfterTx << 6) + (keyType << 5) + (securityLevel << 3) + appId)

#define GPD_APPLICATION_ID_SRC_ID 0
#define GPD_APPLICATION_ID_IEEE   2

// Special ACK frame for Schneider PowerTag GP devices.
#define SCHNEIDER_POWERTAG_ACK_CMD 0xFE // with 1 byte (0x00) payload

// The direction
//   gpd->gpp : Incoming
//   gpp->gpd : Outgoing
typedef enum {
	DIRECTION_GPD_TO_GPP = 0,
	DIRECTION_GPP_TO_GPD = 1,
} EmberGpdfDirection;

// Custom NCP commands.
enum {
	XNCP_CMD_INIT_MULTI_RAIL = 0x0e,
	XNCP_CMD_SET_GP_KEY      = 0x0f,
	XNCP_CMD_GET_GP_KEY      = 0x1f,
	XNCP_CMD_PUSH_TX_QUEUE   = 0xa0,
	XNCP_CMD_CLEAR_TX_QUEUE  = 0xa1,
};

// Key to encrypt outgoing GP frames.
static EmberKeyData gpd_key;

static sl_zigbee_event_t gp_transmit_complete_event;

//--------------------------------
// Extern and forward declarations

extern uint8_t sli_mac_get_next_sequence(void);
extern uint8_t sl_mac_lower_mac_get_radio_channel(uint8_t mac_index);
extern void emberDGpSentHandler(EmberStatus status, uint8_t gpepHandle);
extern void emLoadKeyIntoCore(const uint8_t *key);

static EmberPacketAction handle_gp_frame(EmberZigbeePacketType packetType, uint8_t *packetData, uint8_t len);

static void store_gpd_key(uint8_t *key);
static void get_gpd_key(uint8_t *buf, uint8_t *len);

//---------------
// Event handlers

static void gp_transmit_complete_event_handler(sl_zigbee_event_t *event)
{
	emberDGpSentHandler(EMBER_SUCCESS, 0);
}

//----------------------
// Implemented Callbacks

/** @brief Init
 * Application init function
 */
void emberAfMainInitCallback(void)
{
	sl_zigbee_event_init(&gp_transmit_complete_event, gp_transmit_complete_event_handler);
	// Load GPD key from NVRAM.
	get_gpd_key(gpd_key.contents, NULL);
}

/** @brief Get XNCP Information
 *
 * This callback enables users to communicate the version number and
 * manufacturer ID of their NCP application to the framework. This information
 * is needed for the EZSP command frame called getXncpInfo. This callback will
 * be called when that frame is received so that the application can report
 * its version number and manufacturer ID to be sent back to the HOST.
 *
 * @param versionNumber The version number of the NCP application.
 * @param manufacturerId The manufacturer ID of the NCP application.
 */
void emberAfPluginXncpGetXncpInformation(uint16_t *manufacturerId, uint16_t *versionNumber)
{
	*manufacturerId = 0xBABA;
	*versionNumber = 0x1000;
}

/** @brief Incoming Custom EZSP Message Callback
 *
 * This function is called when the NCP receives a custom EZSP message from the
 * HOST.  The message length and payload is passed to the callback in the first
 * two arguments.  The implementation can then fill in the replyData and set
 * the replayPayloadLength to the number of bytes in the replyData.
 * See documentation for the function ezspCustomFrame on sending these messages
 * from the HOST.
 *
 * @param msgLen The length of the msgData.
 * @param msgData The custom message that was sent from the HOST.
 * @param replyLen The length of the replyData.  This needs to be
 * set by the implementation in order for a properly formed response to be sent
 * back to the HOST.
 * @param replyData The custom message to send back to the HOST in response
 * to the custom message.
 *
 * @return An ::EmberStatus indicating the result of the custom message
 * handling.  This returned status is always the first byte of the EZSP
 * response.
 */
EmberStatus emberAfPluginXncpIncomingCustomFrameCallback(uint8_t msgLen, uint8_t *msgData,
    uint8_t *replyLen, uint8_t *replyData)
{
	// In our custom xNCP protocol, the command ID is always the first byte.
	uint8_t cmd = msgData[0];
	msgData++, msgLen--;

	if (cmd == XNCP_CMD_INIT_MULTI_RAIL) {
		emberGpClearTxQueue();
		RAIL_Handle_t h = emberAfPluginMultirailInit(NULL, NULL,
		    true, RAIL_GetTxPowerDbm(emberGetRailHandle()), NULL,
		    0, 0xFFFF, NULL);
		return (h == NULL) ? EMBER_ERR_FATAL : EMBER_SUCCESS;
	}

	if (cmd == XNCP_CMD_SET_GP_KEY) {
		if (msgLen != EMBER_ENCRYPTION_KEY_SIZE)
			return EMBER_BAD_ARGUMENT;

		store_gpd_key(msgData);
		memcpy(gpd_key.contents, msgData, EMBER_ENCRYPTION_KEY_SIZE);
		return EMBER_SUCCESS;
	}

	if (cmd == XNCP_CMD_GET_GP_KEY) {
		get_gpd_key(replyData, replyLen);
		return EMBER_SUCCESS;
	}

	if (cmd == XNCP_CMD_PUSH_TX_QUEUE) {
		// 5B addr + 1B cmd + min 1B payload
		if (msgLen < 7)
			return EMBER_INVALID_CALL;

		EmberGpAddress addr = {0};
		addr.applicationId = msgData[0];
		if (addr.applicationId != EMBER_GP_APPLICATION_SOURCE_ID)
			return EMBER_INVALID_CALL;

		addr.id.sourceId = (uint32_t)msgData[1];
		addr.id.sourceId += (((uint32_t)msgData[2]) << 8);
		addr.id.sourceId += (((uint32_t)msgData[3]) << 16);
		addr.id.sourceId += (((uint32_t)msgData[4]) << 24);

		uint8_t cmd_id = msgData[5];
		msgData += 6, msgLen -= 6;

		return emberDGpSend(true, // bool action
		                    false,// bool useCca
		                    &addr, cmd_id,
		                    msgLen, msgData,
		                    0, 0);
	}

	if (cmd == XNCP_CMD_CLEAR_TX_QUEUE) {
		emberGpClearTxQueue();
		return EMBER_SUCCESS;
	}

	return EMBER_INVALID_CALL;
}

EmberPacketAction emAfPacketHandoffIncomingCallback(EmberZigbeePacketType packetType,
    EmberMessageBuffer packetBuffer, uint8_t index, void *data)
{
	uint8_t len = emberMessageBufferLength(packetBuffer) - index;
	uint8_t packetData[128];
	// Flat packet : [<-----MAC Frame----->|<--8 bytes Appended Info-->]
	emberCopyFromLinkedBuffers(packetBuffer, index, packetData, len);
	return handle_gp_frame(packetType, packetData, len);
}

/** @brief A callback called whenever a secondary instance RAIL event occurs.
 *
 * @param[in] handle A handle for a RAIL instance.
 * @param[in] events A bit mask of RAIL events (full list in rail_types.h)
 */
void emberAfPluginMultirailRailEventCallback(RAIL_Handle_t handle, RAIL_Events_t events)
{
	if (events & RAIL_EVENT_TX_PACKET_SENT) {
		sl_zigbee_event_set_delay_ms(&gp_transmit_complete_event, 0);
	}
	(void)handle; // unreferenced parameter
}

/** @brief
 *
 * Application framework equivalent of ::emberRadioNeedsCalibratingHandler
 */
void emberAfRadioNeedsCalibratingCallback(void)
{
	sl_mac_calibrate_current_channel();
}


//-----------------
// Static functions

static void
store_gpd_key(uint8_t *key)
{
	tokTypeGpdSecurityKey token;
	memcpy(token.contents, key, EMBER_ENCRYPTION_KEY_SIZE);
	halCommonSetToken(TOKEN_GPD_SECURITY_KEY, &token);
}

static void
get_gpd_key(uint8_t *buf, uint8_t *len)
{
	tokTypeGpdSecurityKey token;
	halCommonGetToken(&token, TOKEN_GPD_SECURITY_KEY);
	memcpy(buf, token.contents, EMBER_ENCRYPTION_KEY_SIZE);
	if (len)
		*len = EMBER_ENCRYPTION_KEY_SIZE;
}

static void
initializeNonce(bool direction, uint8_t *nonce,
    EmberGpAddress *gpdAddr, uint32_t gpdSecurityFrameCounter)
{
	// ScrId
	assert(gpdAddr->applicationId == GPD_APPLICATION_ID_SRC_ID);

	if (direction) { // from GPD --> GPP/GPS : direction bit = 0 in NW FC Header
		emberStoreLowHighInt32u(nonce, gpdAddr->id.sourceId);
		emberStoreLowHighInt32u(nonce+4, gpdAddr->id.sourceId);
	} else { // from GPP/GPS --> GPD : direction bit = 1 in NW FC Header
		emberStoreLowHighInt32u(nonce, 0);
		emberStoreLowHighInt32u(nonce+4, gpdAddr->id.sourceId);
	}

	// Frame counter.
	emberStoreLowHighInt32u(nonce+8, gpdSecurityFrameCounter);
	// Security control
	nonce[12] = 0x05;
}

static uint8_t
prepareHeader(EmberGpdfDirection direction,
    bool rxAfterTx, uint8_t *header, EmberGpAddress *gpdAddr,
    uint8_t keyType, uint8_t securityLevel, uint32_t secFrameCounter)
{
	assert(gpdAddr->applicationId == GPD_APPLICATION_ID_SRC_ID);

	uint8_t len = 0;
	header[len++] = HEADER_FLAG_NWK_FC;
	header[len++] = MAKE_HEADER_FLAG_NWK_FC_EXT(direction, rxAfterTx, keyType, securityLevel, gpdAddr->applicationId);

	emberStoreLowHighInt32u(header+len, gpdAddr->id.sourceId);
	len += 4;

	if (securityLevel >= EMBER_GP_SECURITY_LEVEL_FC_MIC) {
		emberStoreLowHighInt32u(header+len, secFrameCounter);
		len += 4;
	}
	return len;
}

static inline uint8_t
appendPayload(uint8_t *dst, uint8_t cmd_id, uint8_t *data)
{
	if (dst == NULL)
		return 0;

	uint8_t len = 0;
	dst[len++] = cmd_id;
	if (data == NULL)
		return len;

	if (data[0] == 0xFF) {
		dst[len++] = 0xFF;
	} else if (data[0] < MAX_PAYLOAD_LEN) {
		memcpy(dst+len, data+1, data[0]);
		len += data[0];
	} else {
		return 0;
	}
	return len;
}

// Secure outgoing GPDF frame creation
// Inputs :
//   gpdAddr           : Gpd address
//   secFrameCounter   : Security frame counter
//   keyType           : Key Type [Shared Key = 0, Individual Key = 1]
//   key               : Key
//   securityLevel     : 0 (No security), 2 (MIC), or 3 (MIC + encryption)
//   gpdCommandId      : GPD Command Id
//   gpdCommandPayload : GPD Command payload = [payloadlength, <payload bytes>]
//   outFrame          : Output buffer to collect the secured GPDF
//   outFrameSize      : Size of outFrame buffer.
// Returns :
//   totalLength       : Length of the secured GPDF
static uint8_t
emGpOutgoingCommandEncrypt(EmberGpAddress *gpdAddr,
    uint32_t secFrameCounter, uint8_t keyType, EmberKeyData *key,
    uint8_t securityLevel, uint8_t gpdCommandId, uint8_t *gpdCommandPayload,
    uint8_t *outFrame, uint8_t outFrameSize)
{
	if (outFrame == NULL)
		return 0;

	// GP Spec Ref : A.1.4.1 Generic GPDF Frame Format
	// The secure frame storage need, the supplied storage must be greater than the folowing min length
	// NWK FC | EXT NWK FC | EP/SRC ID | FC | GPD Command Id | Payload    | MIC |
	//   1    |    1       |  1/4      | 0/4|       1        | 0-Variable | 0/4 |
	uint8_t minFrameLen = 2
	    + ((gpdAddr->applicationId == GPD_APPLICATION_ID_IEEE) ? 1 : 4)
	    + ((securityLevel == EMBER_GP_SECURITY_LEVEL_NONE) ? 0 : 4)
	    + 1
	    + ((gpdCommandPayload == NULL) ? 0 : ((gpdCommandPayload[0] == 0xFF) ? 1 : gpdCommandPayload[0]))
	    + ((securityLevel == EMBER_GP_SECURITY_LEVEL_NONE) ? 0 : 4);

	if (outFrameSize < minFrameLen)
		return 0;

	uint8_t hdr_len = prepareHeader(DIRECTION_GPP_TO_GPD, false,
	    outFrame, gpdAddr, keyType, securityLevel, secFrameCounter);
	uint8_t payload_len = appendPayload(outFrame+hdr_len,
	    gpdCommandId, gpdCommandPayload);
	uint8_t total_len = hdr_len + payload_len;

	if (securityLevel < EMBER_GP_SECURITY_LEVEL_FC_MIC)
		return total_len;

	// The following code for the security level 2 or 3
	// Prepare nonce
	uint8_t nonce[SECURITY_BLOCK_SIZE] = {0};
	initializeNonce(false, nonce, gpdAddr, secFrameCounter);

	uint8_t auth_len;
	uint8_t enc_offset;
	uint8_t enc_len;

	if (securityLevel == EMBER_GP_SECURITY_LEVEL_FC_MIC) {
		enc_offset = total_len;
		auth_len = total_len;
		enc_len = 0;
	} else {
		enc_offset = hdr_len;
		auth_len = hdr_len;
		enc_len = payload_len;
	}
	emLoadKeyIntoCore(key->contents);
	// Calculate MIC
	emberCcmCalculateAndEncryptMic(nonce,
	    outFrame, auth_len,
	    outFrame + enc_offset, enc_len,
	    &outFrame[total_len]);
	total_len += 4;

	// Encrypt
	if (securityLevel == EMBER_GP_SECURITY_LEVEL_FC_MIC_ENCRYPTED) {
		emberCcmEncryptBytes(outFrame+enc_offset, payload_len, nonce);
	}
	return total_len;
}

// Get an entry with the specified addr from the GP queue if available
static uint8_t pop_gp_tx_queue(EmberGpAddress *addr, uint8_t *buf, uint8_t bufsz)
{
	EmberGpTxQueueEntry entry;
	memcpy(&entry.addr, addr, sizeof(EmberGpAddress));

	uint16_t dlen;
	if (emberGpGetTxQueueEntryFromQueue(&entry, buf+1, &dlen, bufsz-1) == EMBER_NULL_MESSAGE_BUFFER)
		return 0;
	buf[0] = dlen;

	// Remove entry from queue
	emberGpRemoveFromTxQueue(&entry);
	return entry.gpdCommandId;
}

#define MAC_TO_APP_DELAY(ts) ((RAIL_GetTime() & 0x00FFFFFF) - (ts))

static uint8_t mac_hdr[7] = {0x01, 0x08, 0x00, 0xff, 0xff, 0xff, 0xff};
static RAIL_SchedulerInfo_t schedulerInfo = {
	.priority = 10,   // 0 = highest priority, 255 = lowest
	.slipTime = 3000, // allow up to 3ms extra offset
	.transactionTime = 5000, // just a guess how long it takes to send the packet
};

static void
handle_channel_request(uint8_t fc, uint8_t next_chan, uint32_t timestamp)
{
	uint8_t our_channel = sl_mac_lower_mac_get_radio_channel(0);
	uint8_t pkt[13] = {
		// Frame size (+ 2 bytes for CRC)
		12,
		// MAC header
		0x01, 0x08, 0x00, 0xff, 0xff, 0xff, 0xff,
		// Frame Control
		fc,
		// Command and payload
		GP_CMD_CHANNEL_CONFIG, our_channel - 11,
		// CRC placeholders
		0x00, 0x00,
	};

	// Make sure we still have enough time to schedule the reply.
	uint32_t delay = MAC_TO_APP_DELAY(timestamp);
	if (delay > GP_RX_OFFSET_USEC)
		return;

	pkt[3] = sli_mac_get_next_sequence();

	RAIL_ScheduleTxConfig_t tx_config = {
		.mode = RAIL_TIME_DELAY,
		.when = GP_RX_OFFSET_USEC - delay,
	};

	(void)emberAfPluginMultirailSend(pkt, sizeof(pkt),
		our_channel, &tx_config, &schedulerInfo);
}

static EmberPacketAction
handle_gp_frame(EmberZigbeePacketType pktType, uint8_t *inPkt, uint8_t inlen)
{
	// MAC Frame:
	// [<---------------MAC Header------------->||<------------------------------------NWK Frame----------------------------------->]
	// FC(2) | Seq(1) | DstPan(2) | DstAddr(2) || FC(1) | ExtFC(0/1) | SrcId(0/4) | SecFc(0/4) | MIC(0/4) | <------GPDF(1/n)------>
	// FC    : ExtFC Present(b7)=1| AC(b6)=0| Protocol Ver(b5-b2)=3 GP frames| Frame Type(b1-b0) = 0
	// ExtFC :  rxAfteTX (b6) = 1 |  AppId(b2-b0) = 0
	if (pktType != EMBER_ZIGBEE_PACKET_TYPE_RAW_MAC || inlen < 13)
		return EMBER_ACCEPT_PACKET;

	uint8_t fc = inPkt[7];

	// Check for Channel Request frame
	if (fc == 0x0d && inPkt[8] == GP_CMD_CHANNEL_REQ) {
		uint8_t next_chan = (inPkt[9] & 0x0f) + 11;
		// The last 3 bytes of the packet contain the MAC timestamp
		uint32_t macTimeStamp =
			  ((uint32_t)inPkt[inlen - 3] << 16)
			+ ((uint32_t)inPkt[inlen - 2] << 8)
			+ ((uint32_t)inPkt[inlen - 1]);

		handle_channel_request(fc, next_chan, macTimeStamp);
		// We handled the Channel Request, so don't forward it to the NCP
		return EMBER_DROP_PACKET;
	}

	uint8_t extfc = inPkt[8];
	// Only match data frames from GPD, with rxAfterTx bit set and full security (0x3).
	if (fc != 0x8c || extfc != 0x58)
		return EMBER_ACCEPT_PACKET;

	// The last 3 bytes of the packet contain the MAC timestamp
	uint32_t macTimeStamp =
	      ((uint32_t)inPkt[inlen - 3] << 16)
	    + ((uint32_t)inPkt[inlen - 2] << 8)
	    + ((uint32_t)inPkt[inlen - 1]);
	// Do we have enough time to schedule the response?
	if (MAC_TO_APP_DELAY(macTimeStamp) > GP_RX_OFFSET_USEC)
		return EMBER_ACCEPT_PACKET;

	EmberGpAddress gpdAddr;
	gpdAddr.applicationId = EMBER_GP_APPLICATION_SOURCE_ID;
	memcpy(&gpdAddr.id.sourceId, inPkt+9, sizeof(EmberGpSourceId));

	// Security Frame Counter
	uint32_t sec_fc;
	memcpy(&sec_fc, inPkt+13, 4);

	uint8_t payload[32];
	uint8_t outPkt[64];

	uint8_t cmd_id = pop_gp_tx_queue(&gpdAddr, payload, sizeof(payload));
	if (cmd_id == 0) {
		// No entry in TX queue, use default ACK reply
		cmd_id = SCHNEIDER_POWERTAG_ACK_CMD;
		payload[0] = 1; // Size of payload
		payload[1] = 0; // Actual payload
	}

	uint8_t outPktLen = emGpOutgoingCommandEncrypt(&gpdAddr,
	    sec_fc, 0, &gpd_key, 3,
	    cmd_id, payload,
	    outPkt+8, (uint8_t)sizeof(outPkt)-10);

	// Fill MAC header (7 first bytes)
	memcpy(outPkt+1, mac_hdr, sizeof(mac_hdr));
	outPkt[3] = sli_mac_get_next_sequence();
	outPktLen += (uint8_t)sizeof(mac_hdr);

	// RAIL Frame : [Total Length (excludes itself) | <-----MAC FRAME ---->| 2 byte CRC]
	outPkt[0] = outPktLen + 2; // count the 2 CRC bytes (added by the RAIL lib)
	outPktLen += 3;

	// Make sure we still have enough time to schedule the reply.
	uint32_t delay = MAC_TO_APP_DELAY(macTimeStamp);
	if (delay > GP_RX_OFFSET_USEC)
		return EMBER_ACCEPT_PACKET;

	RAIL_ScheduleTxConfig_t scheduledTxConfig = {
		.mode = RAIL_TIME_DELAY,
		.when = GP_RX_OFFSET_USEC - delay,
	};

	(void)emberAfPluginMultirailSend(outPkt, outPktLen,
	    sl_mac_lower_mac_get_radio_channel(0), &scheduledTxConfig, &schedulerInfo);
	return EMBER_ACCEPT_PACKET;
}
