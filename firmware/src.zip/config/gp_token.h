/*
 * Custom token header.
 */

/*
 * Define a custom token for storing a shared security key used by all
 * Green Power devices.
 */
#define CREATOR_GPD_SECURITY_KEY 0x4750  // 'GP'
#define NVM3KEY_GPD_SECURITY_KEY (NVM3KEY_DOMAIN_USER | 0x4750)

#ifdef DEFINETYPES

typedef struct {
	uint8_t contents[EMBER_ENCRYPTION_KEY_SIZE];
} tokTypeGpdSecurityKey;

#endif

#ifdef DEFINETOKENS

DEFINE_BASIC_TOKEN(GPD_SECURITY_KEY, tokTypeGpdSecurityKey, { { 0, } })

#endif
